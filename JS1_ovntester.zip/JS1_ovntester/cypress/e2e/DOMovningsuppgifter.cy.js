/// <reference types="cypress"/>

beforeEach(() => {
    cy.visit('localhost:5500')
})


describe('DOM tests', () => {

    it('Should display input words in reverse order', () => {

        //given
        const inputString = 'ett två tre'
        const outputString = 'tre två ett'

        //when
        cy.get('[data-testid="reverse input"]').type(inputString)

        //then
        cy.contains(outputString).should('exist')

    })

    it('Should display the number of vowels in the input', () => {

      //given
      const inputString = 'Hej Hoj Haj Haj Hyj Höj'
      const vowelsOutputString = 'eoayö'
      const numberOutputString = '6'

      //when
      cy.get('[data-testid="vowels input"]').type(inputString)

      //then
      cy.contains(vowelsOutputString).should('exist')
      cy.contains(numberOutputString).should('exist')

  })

  it('Should display initials of name input', () => {

    //given
    const inputString = 'John Oscar Carl Doe'
    const outputString = 'JOCD'

    //when
    cy.get('[data-testid="initials input"]').type(inputString)

    //then
    cy.contains(outputString).should('exist')

  })

  it('Should display a formatted version of the phone number input', () => {

    //given
    const inputString = '1234567890'
    const outputString = '(123) 456-7890'

    //when
    cy.get('[data-testid="phone input"]').type(inputString)

    //then
    cy.contains(outputString).should('exist')

  })

  const array = [["abc", "0"], ["Abc", "1"], ["Abc2", "2"], ["Abc2!", "3"], ["AbcAbc2!", "4"]]
  
  array.forEach(args => {

    it('Should display a number based on strength of input password', () => {

      //given
      const inputString = args[0]
      const outputString = args[1]

      //when
      cy.get('[data-testid="password input"]').type(inputString)

      //then
      cy.contains(outputString).should('exist')

    })
    
  })



})