//Ordvändare
const wordSwitcherDiv = document.getElementById('Ordvändare')
const textInputElement = document.getElementById('text input')
const outputElement = document.createElement('h3')

wordSwitcherDiv.appendChild(outputElement)

textInputElement.addEventListener('input', function() {
    let inputString = textInputElement.value
    console.log(inputString)

    const stringArray = inputString.split(' ')
    stringArray.reverse()
    
    outputElement.innerText = stringArray.join(' ')
})




//Vokalkontroll
const vowelControlDiv = document.getElementById('Vokalkontroll')
const vowelInputElement = document.getElementById('vowel input')

const vowelOutputElement = document.createElement('h3')
const vowelCountOutputElement = document.createElement('h3')
vowelControlDiv.appendChild(vowelOutputElement)
vowelControlDiv.appendChild(vowelCountOutputElement)

vowelInputElement.addEventListener('input',  function () {
    let vowelOutputString = ""
    let vowelCount = 0
    let vowelInputString = vowelInputElement.value
    let vowelString = "aeiouyåäö"
    
    for (let index = 0; index < vowelInputString.length; index++) {
        let character = vowelInputString.charAt(index)
    
        if (vowelString.includes(character)) {

            if (!vowelOutputString.includes(character)) {
                
                vowelOutputString += character
                vowelOutputElement.innerText = vowelOutputString
            }
            vowelCount++
            vowelCountOutputElement.innerText = vowelCount
        }
    }
})



//Intitialförkortare
const initalsDiv = document.getElementById('Initialförkortare')
const nameInputElement = document.getElementById('name input')

const initialsOutputElement = document.createElement('h3')
initalsDiv.appendChild(initialsOutputElement)

nameInputElement.addEventListener('input', function() {
    let nameString = nameInputElement.value
    const nameArray = nameString.split(' ')
    let initialsOutputString = ""

    for (let i = 0; i < nameArray.length; i++) {
        initialsOutputString += nameArray[i].charAt(0)
    }

    initialsOutputElement.innerText = 'Initialer: ' + initialsOutputString
})

//Telefonformaterare
const phoneDiv = document.getElementById('Telefonformaterare')
const phoneInputElement = document.getElementById('phone input')

const phoneOutputElement = document.createElement('h3')
phoneDiv.appendChild(phoneOutputElement)

phoneInputElement.addEventListener('input', function() {
    let phoneString = phoneInputElement.value
    let first3 = phoneString.slice(0, 3)
    let second3 = phoneString.slice(3, 6)
    let remaining = phoneString.slice(6, phoneString.length + 1)

    phoneOutputElement.innerText = "(" + first3 + ") " + second3 + "-" + remaining
})


//Lösenordsstyrka
const passwordDiv = document.getElementById('Lösenordsstyrka')
const passwordInputElement = document.getElementById('password input')
const pwStrengthOutputElement = document.createElement('h3')
passwordDiv.appendChild(pwStrengthOutputElement)

passwordInputElement.addEventListener('input', function(){
    let password = passwordInputElement.value
    let strength = 0

    // Check password length
    if (password.length > 7) {
        strength += 1
    }

    // Check for mixed case
    if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
        strength += 1
    }

    // Check for numbers
    if (password.match(/\d/)) {
        strength += 1
    }

    // Check for special characters
    if (password.match(/[^a-zA-Z\d]/)) {
        strength += 1
    }

    pwStrengthOutputElement.innerText = strength
})
