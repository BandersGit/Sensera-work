

const uppg1 = () => {

    // Här skapar du dina variabler "age", "firstname" samt "city" 
    // samt tilldelar dem relevanta värden
    var age = 12
    var firstname = "viktor"
    var city = "solna"


    return { age, firstname, city } // Den här raden kan du ignorera just nu och i kommande test
}
// Uncomment below to run manually
// uppg2()


const uppg2 = () => {


    // Variabeln hasPet skall enbart kunna vara sant eller falskt
    // Skapa variabeln hasPet och get den ett sant eller falskt värde
    // Fyll i namnet på den datatyp som hasPet är, som värde till hasPetType

    const hasPet = true
    const hasPetType = "boolean"

    return { hasPet, hasPetType }
}
// Uncomment below to run manually
// uppg2()

const uppg3 = () => {

    // skriv ut namnet 'Alice' i consolen
    console.log('Alice')

}
// Uncomment below to run manually
// uppg3()


const uppg4 = () => {

    // Skapa en variabel "nameOfDeclaration" med en Sträng
    // Där strängens värde är namnet på någon av de två variabeldeklarationer
    // där man kan ändra på värdet i efterhand

    const nameOfDeclaration = "var"

    return nameOfDeclaration;
}
// Uncomment below to run manually
// uppg4()


const uppg5 = () => {

    // Byt värdet på variabeln från 5 till en annan siffra

    let age = 5
    age = 3;

    return age
}
// Uncomment to run manually
// uppg5()

const uppg6 = () => {

    // Skapa en lista "numberList" med 4 siffror
    // Printa ut listan i consolen
    const numberList = [1, 3, 4, 5]
    console.log(numberList)

    return numberList
}
// Uncomment to run manually
// uppg6()



module.exports = { uppg1, uppg2, uppg3, uppg4, uppg5, uppg6 }