
describe("Uppgiftspaket 1", () => {

    const o = require("../ovningar1")

    test("Uppg. 1", () => {

        const result = o.uppg1();



        expect(typeof result.age).toBe('number')
        expect(typeof result.firstname).toBe('string')
        expect(typeof result.city).toBe('string')



    })

    test("Uppg. 2", () => {

        const result = o.uppg2();

        expect([true, false]).toContain(result.hasPet)
        expect(result.hasPetType).toBe('boolean'.toLowerCase())

    })

    test("Uppg. 3", () => {

        const consoleSpy = jest.spyOn(console, 'log');
        const result = o.uppg3();

        expect(consoleSpy).toHaveBeenCalledWith('Alice')
        consoleSpy.mockReset()
    })

    test("Uppg. 4", () => {

        const answer = o.uppg4();

        expect(["var", "let"]).toContain(answer)

    })

    test("Uppg. 5", () => {

        const age = o.uppg5();

        expect(age).not.toBe(5)
        expect(typeof age).toBe('number')

    })

    test("Uppg. 6", () => {

        const consoleSpy = jest.spyOn(console, 'log');
        const list = o.uppg6();

        expect(list.length).toBe(4)
        list.forEach((val) => {
            expect(typeof val).toBe('number')
        })

        expect(consoleSpy).toHaveBeenCalledWith(list)

    })

    test("Uppg. 7", () => {

        const consoleSpy = jest.spyOn(console, 'log');
        const list = o.uppg6();

        expect(list.length).toBe(4)
        list.forEach((val) => {
            expect(typeof val).toBe('number')
        })

        expect(consoleSpy).toHaveBeenCalledWith(list)

    })



})