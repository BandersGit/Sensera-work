/// <reference types="cypress"/>

describe('Responsivity', () => {
  beforeEach(() => {
    cy.visit('http://localhost:5500')
  })

  it('Should have matching backgrund colors for main-section and aside-section in slim viewport', () => {
    cy.viewport(750, 800)

    cy.get('[data-testid="aside-section"]').then($asideSection => {

      cy.get('[data-testid="main-section"]').then($mainSection => {

        const bgColor1 = $asideSection.css('background-color')
        const bgColor2 = $mainSection.css('background-color')
        expect(bgColor1).to.equal(bgColor2)

      })
    })
  })

  it('Should have a smaller image size in slim viewport than in wide viewport', () => {
    cy.get('[data-testid="aside-section"] img').then($image => {
      const bigImage = parseInt($image.css('width'))

      cy.viewport(750, 800).then(() => {
        const smallImage = parseInt($image.css('width'))
        expect(smallImage).to.be.lessThan(bigImage)
      })
    })
  })

  it('Should display main-section below aside-section in slim viewport', () => {
    cy.viewport(750, 800)

    cy.get('[data-testid="main-section"]').then(($mainSection) => {

      cy.get('[data-testid="aside-section"]').then(($asideSection) => {

        const mainLeftPosition = $mainSection.position().left
        const asideLeftPosition = $asideSection.position().left

        const mainTopPosition = $mainSection.position().top
        const asideTopPosition = $asideSection.position().top

        expect(mainLeftPosition).to.be.closeTo(asideLeftPosition, 20)
        expect(mainTopPosition).to.be.greaterThan(asideTopPosition)
      })
    })
  })
})