/// <reference types="cypress"/>

describe('HTML structure', () => {

  beforeEach(() => {
    cy.visit('http://localhost:5500')
  })

  it('Should have an HTML element', () => {
    cy.get('html').should('exist')
  })

  it('Should have a head element', () => {
    cy.get('head').should('exist')
  })

  it('Should have a body element', () => {
    cy.get('body').should('exist')
  })
})

describe('Header section', () => {

  beforeEach(() => {
    cy.visit('http://localhost:5500')
  })

  it('Should have an element with attribute data-testid="header-section"', () => {
    cy.get('[data-testid="header-section"]').should('exist')
  })

  it('Should not have a white background"', () => {
    cy.get('[data-testid="header-section"]').should('not.have.css', 'background-color', 'rgba(0, 0, 0, 0)');
  })

  it('Should have a header with attribute data-testid="header" within header-section', () => {
    cy.get('[data-testid="header-section"] [data-testid="header"]')
      .as("header")

    cy.get('@header')
      .invoke('text')
      .then((text) => expect(text.length).to.be.greaterThan(0))
  })

  it('Should have a subheader with attribute data-testid="subheader" within header-section', () => {
    cy.get('[data-testid="header-section"] [data-testid="subheader"]')
      .as("subheader")

    cy.get('@subheader')
      .invoke('text')
      .then((text) => expect(text.length).to.be.greaterThan(0))
  })

  it('Should have the header font size be larger than the subheader', () => {
    cy.get('[data-testid="header-section"] [data-testid="header"]')
      .as("header")

    cy.get('[data-testid="header-section"] [data-testid="subheader"]')
      .as("subheader")

    assertFontSizeGreater("@header", "@subheader")
  })
})

describe('Aside section', () => {

  beforeEach(() => {
    cy.visit('http://localhost:5500')
  })


  it('Should have an element with attribute data-testid="aside-section"', () => {

    cy.get('[data-testid="aside-section"]').should('exist')

  })

  it('Should not have a white background"', () => {
    cy.get('[data-testid="aside-section"]').should('not.have.css', 'background-color', 'rgba(0, 0, 0, 0)');
  })

  it('Should have 3 subheadings within the aside-section', () => {
    cy.get('[data-testid="aside-section"] .setRubricStyle')
      .should('have.length', 3)
  })

  it('Should have 3 paragraphs within the aside-sections subheadings', () => {
    cy.get('[data-testid="aside-section"] .setParagraphStyle')
      .should('have.length', 3)
  })

  it('Should have the subheadings font size be larger than the paragraph', () => {
    cy.get('[data-testid="aside-section"] .setRubricStyle')
      .as("subheading")

    cy.get('[data-testid="aside-section"] .setParagraphStyle')
      .as("paragraph")

    assertFontSizeGreater("@subheading", "@paragraph")
  })

  it('Should have a rounded img within the aside-section', () => {
    cy.get('[data-testid="aside-section"] img').then($el => {
      cy.wrap($el).invoke('css', 'border-radius').should('not.eq', '0%')
      cy.wrap($el).invoke('css', 'border-radius').should('not.eq', '0px')
    })
  })
})

describe("Main Section", () => {

  beforeEach(() => {
    cy.visit('http://localhost:5500')
  })

  it('Should have an element with attribute data-testid="main-section"', () => {
    cy.get('[data-testid="main-section"]').should('exist');
  })

  it('Should have a white background"', () => {
    cy.get('[data-testid="main-section"]').should('have.css', 'background-color', 'rgba(0, 0, 0, 0)');
  })

  it('Should have 3 subheadings within the main-section', () => {
    cy.get('[data-testid="main-section"] .setRubricStyle')
      .should('have.length', 3)
  })

  it('Should have 3 paragraphs within the main-sections subheadings', () => {
    cy.get('[data-testid="main-section"] .setParagraphStyle')
      .should('have.length.at.least', 3)
  })

  it('Should have the subheadings font size be larger than the paragraph', () => {
    cy.get('[data-testid="main-section"] .setRubricStyle')
      .as("subheading")

    cy.get('[data-testid="main-section"] .setParagraphStyle')
      .as("paragraph")

    assertFontSizeGreater("@subheading", "@paragraph")
  })
})

const assertFontSizeGreater = (selector1, selector2) => {
  cy.get(selector1).then($el1 => {

    cy.get(selector2).then($el2 => {

      const el1Size = parseInt($el1.css('font-size'))
      const el2Size = parseInt($el2.css('font-size'))
      expect(el1Size).to.be.greaterThan(el2Size)

    })
  })
}
