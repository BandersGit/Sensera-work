/// <reference types="cypress"/>

describe('Inlamningsuppgift 1', () => {

  beforeEach(() => {
    cy.visit("http://localhost:5500/")
  })

  it('Should have an HTML element', () => {
    cy.get('html').should('exist')
  })

  it('Should have a head element', () => {
    cy.get('head').should('exist')
  })

  it('Should have a body element', () => {
    cy.get('body').should('exist')
  })

  it('Should have a table element', () => {
    cy.get('table').should('exist')
  })

  /*
  it('Should have a thead element', () => {
    cy.get('thead').should('exist')
  })

  it('Should have a tbody element', () => {
    cy.get('tbody').should('exist')
  })
  */

  it('Should have at least 3 rows', () => {
    cy.get('tr').should('have.length.at.least', 3)
  })

  it('Should have at least 4 columns', () => {
    cy.get('tr').eq(2).children().should('have.length.at.least', 4)
  })

})